package com.github.ofrostdev.api.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import EventHandler;
import Listener;
import inventory.InventoryCloseEvent;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class InventoryClose implements Listener {

    private static final Map<UUID, Consumer<inventory.InventoryCloseEvent>> listeners = new ConcurrentHashMap<>();
    private static Plugin plugin;

    private InventoryClose() {}

    public static void init(Plugin plugin) {
        if (InventoryClose.plugin != null) return;
        InventoryClose.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(new InventoryClose(), plugin);
    }

    public static void cancel(Player player) {
        listeners.remove(player.getUniqueId());
    }
    public static void listen(Player player, Consumer<inventory.InventoryCloseEvent> callback, boolean keepListening) {
        UUID uuid = player.getUniqueId();
        if (!keepListening) {
            listeners.put(uuid, event -> {
                callback.accept(event);
                listeners.remove(uuid);
            });
        } else {
            listeners.put(uuid, callback);
        }
    }

    @EventHandler
    private void onEvent(InventoryCloseEvent event) {
        Player player = (Player) event.getPlayer();
        Consumer<InventoryCloseEvent> callback = listeners.get(player.getUniqueId());
        if (callback != null) {
            callback.accept(event);
        }
    }
}