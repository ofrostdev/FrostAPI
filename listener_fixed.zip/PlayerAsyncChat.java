package com.github.ofrostdev.api.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import EventHandler;
import Listener;
import player.AsyncPlayerChatEvent;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class PlayerAsyncChat implements Listener {

    private static final Map<UUID, Consumer<AsyncPlayerChatEvent>> listeners = new ConcurrentHashMap<>();
    private static Plugin plugin;

    private PlayerAsyncChat() {}

    public static void init(Plugin plugin) {
        if (PlayerAsyncChat.plugin != null) return;
        PlayerAsyncChat.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(new PlayerAsyncChat(), PlayerAsyncChat.plugin);
    }

    public static void listen(Player player, Consumer<AsyncPlayerChatEvent> callback, boolean keepListening) {
        UUID uuid = player.getUniqueId();
        if (!keepListening) {
            listeners.put(uuid, event -> {
                callback.accept(event);
                listeners.remove(uuid);
            });
        } else {
            listeners.put(uuid, callback);
        }
    }

    @EventHandler
    private void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        Consumer<AsyncPlayerChatEvent> callback = listeners.get(player.getUniqueId());
        if (callback != null) {
            callback.accept(event);
        }
    }

    public static void cancel(Player player) {
        listeners.remove(player.getUniqueId());
    }
}
