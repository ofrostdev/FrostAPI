package com.github.ofrostdev.api.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import EventHandler;
import Listener;
import block.BlockPlaceEvent;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class BlockPlace implements Listener {

    private static final Map<UUID, Consumer<block.BlockPlaceEvent>> listeners = new ConcurrentHashMap<>();
    private static Plugin plugin;

    private BlockPlace() {}

    public static void init(Plugin plugin) {
        if (BlockPlace.plugin != null) return;
        BlockPlace.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(new BlockPlace(), plugin);
    }

    public static void cancel(Player player) {
        listeners.remove(player.getUniqueId());
    }
    public static void listen(Player player, Consumer<block.BlockPlaceEvent> callback, boolean keepListening) {
        UUID uuid = player.getUniqueId();
        if (!keepListening) {
            listeners.put(uuid, event -> {
                callback.accept(event);
                listeners.remove(uuid);
            });
        } else {
            listeners.put(uuid, callback);
        }
    }

    @EventHandler
    private void onEvent(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        Consumer<BlockPlaceEvent> callback = listeners.get(player.getUniqueId());
        if (callback != null) {
            callback.accept(event);
        }
    }
}