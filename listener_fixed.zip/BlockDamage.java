package com.github.ofrostdev.api.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import EventHandler;
import Listener;
import block.BlockDamageEvent;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class BlockDamage implements Listener {

    private static final Map<UUID, Consumer<block.BlockDamageEvent>> listeners = new ConcurrentHashMap<>();
    private static Plugin plugin;

    private BlockDamage() {}

    public static void init(Plugin plugin) {
        if (BlockDamage.plugin != null) return;
        BlockDamage.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(new BlockDamage(), plugin);
    }

    public static void cancel(Player player) {
        listeners.remove(player.getUniqueId());
    }
    public static void listen(Player player, Consumer<block.BlockDamageEvent> callback, boolean keepListening) {
        UUID uuid = player.getUniqueId();
        if (!keepListening) {
            listeners.put(uuid, event -> {
                callback.accept(event);
                listeners.remove(uuid);
            });
        } else {
            listeners.put(uuid, callback);
        }
    }

    @EventHandler
    private void onEvent(BlockDamageEvent event) {
        Player player = event.getPlayer();
        Consumer<BlockDamageEvent> callback = listeners.get(player.getUniqueId());
        if (callback != null) {
            callback.accept(event);
        }
    }
}