    public static void cancel(Player player) {
        listeners.remove(player.getUniqueId());
    }
package com.github.ofrostdev.api.listener;

import org.bukkit.Bukkit;
import Event;
import EventHandler;
import Listener;
import org.bukkit.plugin.Plugin;

import java.util.function.Consumer;

class ListenerAdapter<T extends Event> implements Listener {

    private final Consumer<T> action;

    ListenerAdapter(Plugin plugin, Class<T> eventClass, Consumer<T> action) {
        this.action = action;
        Bukkit.getPluginManager().registerEvents(this, plugin);

        Bukkit.getPluginManager().registerEvent(
                eventClass,
                this,
                EventPriority.NORMAL,
                (listener, event) -> {
                    if (eventClass.isInstance(event)) {
                        handle(eventClass.cast(event));
                    }
                },
                plugin
        );
    }

    @EventHandler
    private void handle(T event) {
        action.accept(event);
    }
}