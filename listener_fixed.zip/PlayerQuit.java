package com.github.ofrostdev.api.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import EventHandler;
import Listener;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class PlayerQuit implements Listener {

    private static final Map<UUID, Consumer<player.PlayerQuitEvent>> listeners = new ConcurrentHashMap<>();
    private static Plugin plugin;

    private PlayerQuit() {}

    public static void init(Plugin plugin) {
        if (PlayerQuit.plugin != null) return;
        PlayerQuit.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(new PlayerQuit(), plugin);
    }

    public static void cancel(Player player) {
        listeners.remove(player.getUniqueId());
    }
    public static void listen(Player player, Consumer<player.PlayerQuitEvent> callback, boolean keepListening) {
        UUID uuid = player.getUniqueId();
        if (!keepListening) {
            listeners.put(uuid, event -> {
                callback.accept(event);
                listeners.remove(uuid);
            });
        } else {
            listeners.put(uuid, callback);
        }
    }

    @EventHandler
    private void onEvent(player.PlayerQuitEvent event) {
        Player player = event.getPlayer();
        Consumer<player.PlayerQuitEvent> callback = listeners.get(player.getUniqueId());
        if (callback != null) {
            callback.accept(event);
        }
    }
}