package com.github.ofrostdev.api.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import EventHandler;
import Listener;
import inventory.InventoryDragEvent;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class InventoryDrag implements Listener {

    private static final Map<UUID, Consumer<inventory.InventoryDragEvent>> listeners = new ConcurrentHashMap<>();
    private static Plugin plugin;

    private InventoryDrag() {}

    public static void init(Plugin plugin) {
        if (InventoryDrag.plugin != null) return;
        InventoryDrag.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(new InventoryDrag(), plugin);
    }

    public static void cancel(Player player) {
        listeners.remove(player.getUniqueId());
    }
    public static void listen(Player player, Consumer<inventory.InventoryDragEvent> callback, boolean keepListening) {
        UUID uuid = player.getUniqueId();
        if (!keepListening) {
            listeners.put(uuid, event -> {
                callback.accept(event);
                listeners.remove(uuid);
            });
        } else {
            listeners.put(uuid, callback);
        }
    }

    @EventHandler
    private void onEvent(InventoryDragEvent event) {
        Player player = (Player) event.getWhoClicked();
        Consumer<InventoryDragEvent> callback = listeners.get(player.getUniqueId());
        if (callback != null) {
            callback.accept(event);
        }
    }
}