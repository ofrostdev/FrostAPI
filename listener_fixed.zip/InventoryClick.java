package com.github.ofrostdev.api.listener;


import org.bukkit.entity.Player;
import inventory.InventoryClickEvent;
import inventory.InventoryCloseEvent;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class InventoryClick {

    private static final Map<UUID, Consumer<InventoryClickEvent>> listeners = new ConcurrentHashMap<>();
    private static Plugin plugin;

    private InventoryClick() {}

    public static void init(Plugin plugin) {
        if (InventoryClick.plugin != null) return;
        InventoryClick.plugin = plugin;

        new ListenerAdapter<>(InventoryClick.plugin, InventoryClickEvent.class, event -> {
            if (!(event.getWhoClicked() instanceof Player)) return;
            Player player = (Player) event.getWhoClicked();

            Consumer<InventoryClickEvent> callback = listeners.get(player.getUniqueId());
            if (callback != null) {
                event.setCancelled(true);
                callback.accept(event);
            }
        });

        new ListenerAdapter<>(InventoryClick.plugin, InventoryCloseEvent.class, event -> {
            if (!(event.getPlayer() instanceof Player)) return;
            Player player = (Player) event.getPlayer();
            listeners.remove(player.getUniqueId());
        });
    }

    public static void cancel(Player player) {
        listeners.remove(player.getUniqueId());
    }
    public static void listen(Player player, Consumer<InventoryClickEvent> callback, boolean keepListening) {
        UUID uuid = player.getUniqueId();
        if (!keepListening) {
            listeners.put(uuid, event -> {
                callback.accept(event);
                listeners.remove(uuid);
            });
        } else {
            listeners.put(uuid, callback);
        }
    }
}