package com.github.ofrostdev.api.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import EventHandler;
import Listener;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class PlayerDropItem implements Listener {

    private static final Map<UUID, Consumer<player.PlayerDropItemEvent>> listeners = new ConcurrentHashMap<>();
    private static Plugin plugin;

    private PlayerDropItem() {}

    public static void init(Plugin plugin) {
        if (PlayerDropItem.plugin != null) return;
        PlayerDropItem.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(new PlayerDropItem(), plugin);
    }

    public static void cancel(Player player) {
        listeners.remove(player.getUniqueId());
    }
    public static void listen(Player player, Consumer<player.PlayerDropItemEvent> callback, boolean keepListening) {
        UUID uuid = player.getUniqueId();
        if (!keepListening) {
            listeners.put(uuid, event -> {
                callback.accept(event);
                listeners.remove(uuid);
            });
        } else {
            listeners.put(uuid, callback);
        }
    }

    @EventHandler
    private void onEvent(player.PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        Consumer<player.PlayerDropItemEvent> callback = listeners.get(player.getUniqueId());
        if (callback != null) {
            callback.accept(event);
        }
    }
}