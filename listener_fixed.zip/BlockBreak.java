package com.github.ofrostdev.api.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import EventHandler;
import Listener;
import block.BlockBreakEvent;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class BlockBreak implements Listener {

    private static final Map<UUID, Consumer<block.BlockBreakEvent>> listeners = new ConcurrentHashMap<>();
    private static Plugin plugin;

    private BlockBreak() {}

    public static void init(Plugin plugin) {
        if (BlockBreak.plugin != null) return;
        BlockBreak.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(new BlockBreak(), plugin);
    }

    public static void cancel(Player player) {
        listeners.remove(player.getUniqueId());
    }
    public static void listen(Player player, Consumer<block.BlockBreakEvent> callback, boolean keepListening) {
        UUID uuid = player.getUniqueId();
        if (!keepListening) {
            listeners.put(uuid, event -> {
                callback.accept(event);
                listeners.remove(uuid);
            });
        } else {
            listeners.put(uuid, callback);
        }
    }

    @EventHandler
    private void onEvent(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Consumer<BlockBreakEvent> callback = listeners.get(player.getUniqueId());
        if (callback != null) {
            callback.accept(event);
        }
    }
}