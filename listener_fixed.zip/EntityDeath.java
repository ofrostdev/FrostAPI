package com.github.ofrostdev.api.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import EventHandler;
import Listener;
import entity.EntityDeathEvent;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class EntityDeath implements Listener {

    private static final Map<UUID, Consumer<entity.EntityDeathEvent>> listeners = new ConcurrentHashMap<>();
    private static Plugin plugin;

    private EntityDeath() {}

    public static void init(Plugin plugin) {
        if (EntityDeath.plugin != null) return;
        EntityDeath.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(new EntityDeath(), plugin);
    }

    public static void cancel(Player player) {
        listeners.remove(player.getUniqueId());
    }
    public static void listen(Player player, Consumer<entity.EntityDeathEvent> callback, boolean keepListening) {
        UUID uuid = player.getUniqueId();
        if (!keepListening) {
            listeners.put(uuid, event -> {
                callback.accept(event);
                listeners.remove(uuid);
            });
        } else {
            listeners.put(uuid, callback);
        }
    }

    @EventHandler
    private void onEvent(EntityDeathEvent event) {
        listeners.values().forEach(callback -> callback.accept(event));
        Player player = (Player) event.getEntity();
        Consumer<EntityDeathEvent> callback = listeners.get(player.getUniqueId());
        if (callback != null) {
            callback.accept(event);
        }
    }
}