package com.github.ofrostdev.api.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import EventHandler;
import Listener;
import entity.EntityPickupItemEvent;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class EntityPickupItem implements Listener {

    private static final Map<UUID, Consumer<entity.EntityPickupItemEvent>> listeners = new ConcurrentHashMap<>();
    private static Plugin plugin;

    private EntityPickupItem() {}

    public static void init(Plugin plugin) {
        if (EntityPickupItem.plugin != null) return;
        EntityPickupItem.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(new EntityPickupItem(), plugin);
    }

    public static void cancel(Player player) {
        listeners.remove(player.getUniqueId());
    }
    public static void listen(Player player, Consumer<entity.EntityPickupItemEvent> callback, boolean keepListening) {
        UUID uuid = player.getUniqueId();
        if (!keepListening) {
            listeners.put(uuid, event -> {
                callback.accept(event);
                listeners.remove(uuid);
            });
        } else {
            listeners.put(uuid, callback);
        }
    }

    @EventHandler
    private void onEvent(EntityPickupItemEvent event) {
        listeners.values().forEach(callback -> callback.accept(event));
        Player player = (Player) event.getEntity();
        Consumer<EntityPickupItemEvent> callback = listeners.get(player.getUniqueId());
        if (callback != null) {
            callback.accept(event);
        }
    }
}