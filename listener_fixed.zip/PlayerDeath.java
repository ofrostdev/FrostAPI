package com.github.ofrostdev.api.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import EventHandler;
import Listener;
import entity.PlayerDeathEvent;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class PlayerDeath implements Listener {

    private static final Map<UUID, Consumer<PlayerDeathEvent>> listeners = new ConcurrentHashMap<>();
    private static Plugin plugin;

    private PlayerDeath() {}

    public static void init(Plugin plugin) {
        if (PlayerDeath.plugin != null) return;
        PlayerDeath.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(new PlayerDeath(), plugin);
    }

    public static void cancel(Player player) {
        listeners.remove(player.getUniqueId());
    }
    public static void listen(Player player, Consumer<PlayerDeathEvent> callback, boolean keepListening) {
        UUID uuid = player.getUniqueId();
        if (!keepListening) {
            listeners.put(uuid, event -> {
                callback.accept(event);
                listeners.remove(uuid);
            });
        } else {
            listeners.put(uuid, callback);
        }
    }

    @EventHandler
    private void onEvent(PlayerDeathEvent event) {
        Player player = event.getEntity();
        Consumer<PlayerDeathEvent> callback = listeners.get(player.getUniqueId());
        if (callback != null) {
            callback.accept(event);
        }
    }
}