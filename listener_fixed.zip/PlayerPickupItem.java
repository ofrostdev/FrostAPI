package com.github.ofrostdev.api.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import EventHandler;
import Listener;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class PlayerPickupItem implements Listener {

    private static final Map<UUID, Consumer<player.PlayerPickupItemEvent>> listeners = new ConcurrentHashMap<>();
    private static Plugin plugin;

    private PlayerPickupItem() {}

    public static void init(Plugin plugin) {
        if (PlayerPickupItem.plugin != null) return;
        PlayerPickupItem.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(new PlayerPickupItem(), plugin);
    }

    public static void cancel(Player player) {
        listeners.remove(player.getUniqueId());
    }
    public static void listen(Player player, Consumer<player.PlayerPickupItemEvent> callback, boolean keepListening) {
        UUID uuid = player.getUniqueId();
        if (!keepListening) {
            listeners.put(uuid, event -> {
                callback.accept(event);
                listeners.remove(uuid);
            });
        } else {
            listeners.put(uuid, callback);
        }
    }

    @EventHandler
    private void onEvent(player.PlayerPickupItemEvent event) {
        Player player = event.getPlayer();
        Consumer<player.PlayerPickupItemEvent> callback = listeners.get(player.getUniqueId());
        if (callback != null) {
            callback.accept(event);
        }
    }
}