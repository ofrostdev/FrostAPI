package com.github.ofrostdev.api.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import EventHandler;
import Listener;
import entity.EntityDamageEvent;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class EntityDamage implements Listener {

    private static final Map<UUID, Consumer<EntityDamageEvent>> listeners = new ConcurrentHashMap<>();
    private static Plugin plugin;

    private EntityDamage() {}

    public static void init(Plugin plugin) {
        if (EntityDamage.plugin != null) return;
        EntityDamage.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(new EntityDamage(), plugin);
    }

    public static void cancel(Player player) {
        listeners.remove(player.getUniqueId());
    }
    public static void listen(Player player, Consumer<EntityDamageEvent> callback, boolean keepListening) {
        UUID uuid = player.getUniqueId();
        if (!keepListening) {
            listeners.put(uuid, event -> {
                callback.accept(event);
                listeners.remove(uuid);
            });
        } else {
            listeners.put(uuid, callback);
        }
    }

    @EventHandler
    private void onEvent(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) return;

        Player player = (Player) event.getEntity();
        Consumer<EntityDamageEvent> callback = listeners.get(player.getUniqueId());
        if (callback != null) {
            callback.accept(event);
        }
    }
}