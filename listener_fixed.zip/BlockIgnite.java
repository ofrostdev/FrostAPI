package com.github.ofrostdev.api.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import EventHandler;
import Listener;
import block.BlockIgniteEvent;
import entity.EntityPickupItemEvent;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class BlockIgnite implements Listener {

    private static final Map<UUID, Consumer<block.BlockIgniteEvent>> listeners = new ConcurrentHashMap<>();
    private static Plugin plugin;

    private BlockIgnite() {}

    public static void init(Plugin plugin) {
        if (BlockIgnite.plugin != null) return;
        BlockIgnite.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(new BlockIgnite(), plugin);
    }

    public static void cancel(Player player) {
        listeners.remove(player.getUniqueId());
    }
    public static void listen(Player player, Consumer<block.BlockIgniteEvent> callback, boolean keepListening) {
        UUID uuid = player.getUniqueId();
        if (!keepListening) {
            listeners.put(uuid, event -> {
                callback.accept(event);
                listeners.remove(uuid);
            });
        } else {
            listeners.put(uuid, callback);
        }
    }

    @EventHandler
    private void onEvent(BlockIgniteEvent event) {
        listeners.values().forEach(callback -> callback.accept(event));
        Consumer<BlockIgniteEvent> callback = listeners.get(event.getPlayer().getUniqueId());
        if (callback != null) {
            callback.accept(event);
        }
    }
}